import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

const DICE_GRAPHQL_URL = 'https://partners-endpoint.dice.fm/graphql';
const DICE_REQUEST_TIMEOUT_MS = 15000;

async function executeDiceQuery(query: string, apiKey: string) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort('timeout'), DICE_REQUEST_TIMEOUT_MS);

  try {
    const response = await fetch(DICE_GRAPHQL_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ query }),
      signal: controller.signal,
    });

    const data = await response.json();
    return { response, data };
  } finally {
    clearTimeout(timeoutId);
  }
}

async function fetchAllViewerEvents(apiKey: string) {
  const allEdges: any[] = [];
  let hasNextPage = true;
  let afterCursor: string | null = null;
  let totalCount = 0;

  while (hasNextPage) {
    const afterClause = afterCursor ? `, after: "${afterCursor}"` : '';
    const query = `{
      viewer {
        events(first: 50${afterClause}) {
          totalCount
          pageInfo {
            hasNextPage
            endCursor
          }
          edges {
            node {
              id
              name
              state
              startDatetime
              endDatetime
              totalTicketAllocationQty
              ticketTypes {
                id
                name
                price
                totalTicketAllocationQty
              }
              tickets(first: 0) {
                totalCount
              }
            }
          }
        }
      }
    }`;

    const { response, data } = await executeDiceQuery(query, apiKey);

    if (!response.ok) {
      throw new Error(`DICE API error: ${response.status}`);
    }

    const eventsNode = data?.data?.viewer?.events;
    const edges = eventsNode?.edges || [];

    totalCount = eventsNode?.totalCount || totalCount;
    allEdges.push(...edges);

    hasNextPage = Boolean(eventsNode?.pageInfo?.hasNextPage);
    afterCursor = eventsNode?.pageInfo?.endCursor || null;

    if (!afterCursor || (totalCount > 0 && allEdges.length >= totalCount)) {
      hasNextPage = false;
    }
  }

  return {
    data: {
      viewer: {
        events: {
          totalCount,
          edges: allEdges,
        },
      },
    },
  };
}

function getTodayISO(): string {
  // Use Italian timezone so "today" resets at midnight Rome time
  const now = new Date();
  const rome = now.toLocaleDateString('en-CA', { timeZone: 'Europe/Rome' }); // returns YYYY-MM-DD
  return rome;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get('DICE_API_KEY');
    if (!apiKey) {
      return new Response(
        JSON.stringify({ success: false, error: 'DICE_API_KEY not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    let body: Record<string, any> = {};
    try {
      const rawBody = await req.text();
      body = rawBody ? JSON.parse(rawBody) : {};
    } catch (_parseError) {
      console.warn('Invalid or empty JSON body, using default action fetch_events');
    }

    const action = typeof body.action === 'string' ? body.action : 'fetch_events';

    if (action === 'fetch_events') {
      let data: any;
      try {
        data = await fetchAllViewerEvents(apiKey);
      } catch (apiError) {
        console.error('DICE API error:', apiError);
        return new Response(
          JSON.stringify({ success: false, error: apiError instanceof Error ? apiError.message : 'DICE API error' }),
          { status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Save daily baseline snapshot (only the FIRST fetch of the day is kept)
      let todayBaseline: any[] | null = null;
      try {
        const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
        const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
        const sb = createClient(supabaseUrl, supabaseKey);
        const today = getTodayISO();

        const edges = data?.data?.viewer?.events?.edges || [];
        const activeEdges = edges.filter((edge: any) => edge.node.state !== 'CANCELLED');
        const rows = activeEdges.map((edge: any) => ({
          event_id: edge.node.id,
          event_name: edge.node.name,
          ticket_type: 'total',
          tickets_sold: edge.node.tickets?.totalCount || 0,
          snapshot_date: today,
        }));

        if (rows.length > 0) {
          // INSERT only if no snapshot exists for today (preserves first-of-day baseline)
          await sb
            .from('ticket_snapshots')
            .upsert(rows, { onConflict: 'event_id,snapshot_date', ignoreDuplicates: true })
            .throwOnError();
        }

        // Always return today's baseline
        const { data: baselineData } = await sb
          .from('ticket_snapshots')
          .select('event_id, event_name, tickets_sold')
          .eq('snapshot_date', today);
        todayBaseline = baselineData;

        // Also get yesterday's baseline for % comparison
        const { data: prevDates } = await sb
          .from('ticket_snapshots')
          .select('snapshot_date')
          .lt('snapshot_date', today)
          .order('snapshot_date', { ascending: false })
          .limit(1);

        let yesterdayBaseline = null;
        let yesterdayDate = null;
        if (prevDates && prevDates.length > 0) {
          yesterdayDate = prevDates[0].snapshot_date;
          const { data: ydData } = await sb
            .from('ticket_snapshots')
            .select('event_id, event_name, tickets_sold')
            .eq('snapshot_date', yesterdayDate);
          yesterdayBaseline = ydData;
        }

        return new Response(
          JSON.stringify({
            success: true,
            data,
            todayBaseline,
            yesterdayBaseline,
            yesterdayDate,
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      } catch (snapErr) {
        console.error('Snapshot error (non-blocking):', snapErr);
        return new Response(
          JSON.stringify({ success: true, data, todayBaseline: null, yesterdayBaseline: null }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }




    if (action === 'fetch_event_tickets') {
      const eventId = body.eventId;
      if (!eventId || typeof eventId !== 'string') {
        return new Response(
          JSON.stringify({ success: false, error: 'Missing or invalid eventId' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const query = `{
        node(id: "${eventId}") {
          ... on Event {
            id
            name
            ticketTypes {
              id
              name
              price
              totalTicketAllocationQty
            }
            tickets(first: 0) {
              totalCount
            }
          }
        }
      }`;

      const { data } = await executeDiceQuery(query, apiKey);

      return new Response(
        JSON.stringify({ success: true, data }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ success: false, error: 'Unknown action' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ success: false, error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
